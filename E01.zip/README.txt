Make sure to update SUBMIT.txt before you submit.

The following files must be included in the final submission:

- SUBMIT.txt
- E01_01.sql
- E01_02.py
- E01_03.sql
- E01_03.csv
- E01_04.sql
- E01_04.csv
- E01_05.txt
- import.sql

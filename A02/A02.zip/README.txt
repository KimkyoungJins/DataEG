Make sure to update SUBMIT.txt before you submit.

The following files must be included in the final submission:

- SUBMIT.txt
- A02_01.sql
- A02_01.csv
- A02_02.sql
- A02_02.csv
- A02_03.sql
- A02_03.csv
- A02_04.sql
- A02_04.csv
- A02_05.sql
- A02_05.csv
- A02_06.sql
- A02_06.csv
- A02_07.sql
- A02_07.csv
- A02_08.sql
- A02_08.csv
- A02_09.sql
- A02_09.csv
- A02_10.sql
- A02_10.csv
- A02_11.sql
- A02_11.csv
- A02_12.sql
- A02_12.csv
- A02_13.sql
- A02_13.csv
- A02_14.sql
- A02_14.csv
- A02_15.sql
- A02_15.csv

SELECT *
FROM Bible
WHERE book = 'John' 
  AND chapter = 3
  AND verse = 16;
